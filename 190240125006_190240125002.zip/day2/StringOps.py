s = input("Enter String: ")
print("values at even index",s[0::2])
print("values at odd index",s[1::2],len(s))
print(s+"a"*len(s))
