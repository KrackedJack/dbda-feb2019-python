import Person as p

print(p.Employee(1,"name","dept","job"))
print(p.SalariedEmployee(1,"name","dept","job",1236,65))
print(p.ContractEmployee(1,"name","dept","job",1236,65))