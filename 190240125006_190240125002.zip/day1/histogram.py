def histogram(a):
	for value in a:
		print(value,": ", value*"*")


histogram([20,26,38,50,32])