import pandas as pd
mydata1=pd.read_csv("http://bit.ly/uforeports")
print(type(mydata1))#will print dataframe

#to retrieve any one column
print(mydata1.City)
#print(mydata1["City"])
#To add location column and populate it with values
#City , state vlaues
mydata1["location"]=mydata1.City + " , "+ mydata1.State
#print(mydata1["location"])
print(mydata1.columns)
mydata1.columns=mydata1.columns.str.replace(" ","-") #to convert column names in to string and then use replace function
#print(mydata1.columns)

print("using condition")
print(mydata1.loc[mydata1["Shape-Reported"]=="OTHER"])
#mydata1.drop('Colors reported', axis=1,inplace=True) #axis=1 says columns axis=0 indicates row
print(mydata1.head())
print(mydata1.shape)
#to delete first 2 rows axis=0 indicates row
mydata1.drop([0,1],axis=0,inplace=True)


