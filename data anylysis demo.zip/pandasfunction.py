import pandas as pd
import numpy as np




data = pd.read_csv("train.csv", index_col="Loan_ID")
#to list of all females who are not graduate and
#got a loan. Boolean indexing can help here
data.loc[(data["Gender"]=="Female") & (data["Education"]=="Not Graduate") & (data["Loan_Status"]=="Y"), ["Gender","Education","Loan_Status"]]
#It is one of the commonly used functions for playing with
#data and creating new variables.
#Apply returns some value after passing each row/column of a data frame with some function. The function can be both default or user-defined.
#Create a new function:
def num_missing(x):
  return sum(x.isnull())

#Applying per column:
print "Missing values per column:"
print data.apply(num_missing, axis=0) #axis=0 defines that function is to be applied on each column

#Applying per row:
print "\nMissing values per row:"
print data.apply(num_missing, axis=1).head() #axis=1 defines that function is to be applied on each row


#Impute the values:
data['Gender'].fillna(mode(data['Gender']).mode[0], inplace=True)
data['Married'].fillna(mode(data['Married']).mode[0], inplace=True)
data['Self_Employed'].fillna(mode(data['Self_Employed']).mode[0], inplace=True)

#Now check the #missing values again to confirm:
print data.apply(num_missing, axis=0)


#sort frame

data_sorted = data.sort_values(['ApplicantIncome','CoapplicantIncome'], ascending=False)
