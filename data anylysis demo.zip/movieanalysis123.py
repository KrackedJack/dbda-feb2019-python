import pandas as pd
from pandas import DataFrame as df

movies_df = pd.read_csv("movies.csv")

# now lets move onto the movie ratings data
ratings_path = './ratings.csv'
ratings_df = pd.read_csv("ratings.csv")

#merged_df = pd.merge(ratings_df, movies_df, on='movieId')
#print(merged_df.head())
# lets check how many ratings have these movies received, lets take an example of movieId 163949
##print("length : ",len(ratings_df[ratings_df['movieId'] == 2794].index))
#print("length : ",len(ratings_df.index))
movies_df['genres_arr'] = movies_df['genres'].str.split('|')
print(movies_df.head())

counter_lambda = lambda x: len(x)
movies_df['genre_count'] = movies_df.genres_arr.apply(counter_lambda)
print(movies_df.head())

import matplotlib.pyplot as plt

plt.hist(movies_df.genre_count)
plt.title("Genres Histogram")
plt.xlabel("# of genres")
plt.ylabel("# of movies")
plt.axis([0, 9, 0, 5000])
plt.show()

# now lets see how many movies are there for each genre

from collections import Counter

flattened_genres = [item for sublist in movies_df.genres_arr for item in sublist]

genre_dict = dict(Counter(flattened_genres))

print(genre_dict)


# now lets plot this genre distribution as a pie chart
plt.pie(genre_dict.values(), labels=genre_dict.keys())
plt.title('Genre distribution of movies')
plt.show()

# we can also save the plot as an image to share with other
plt.savefig('./movie-genres-pie.png')
